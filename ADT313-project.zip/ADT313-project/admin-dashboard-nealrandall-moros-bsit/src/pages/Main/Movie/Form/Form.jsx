import axios from 'axios';
import { useCallback, useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { useNavigate } from 'react-router-dom';
import './Form.css';
const Form = () => {
  const [query, setQuery] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const moviesPerPage = 5;                           
  const [totalPages = Math.ceil(searchedMovieList.length / moviesPerPage), setTotalPages] = useState(1);    
  const [searchedMovieList, setSearchedMovieList] = useState([]);
  const [selectedMovie, setSelectedMovie] = useState(undefined);
  const [movie, setMovie] = useState(undefined);
  const indexOfLastMovie = currentPage * moviesPerPage;
  const indexOfFirstMovie = indexOfLastMovie - moviesPerPage;
  const currentMovies = searchedMovieList.slice(indexOfFirstMovie, indexOfLastMovie);
  
  let { movieId } = useParams();

  const handleSearch = useCallback(async () => {
    try {
      const response = await axios({
        method: 'get',
        url: `https://api.themoviedb.org/3/search/movie?query=${query}&include_adult=false&language=en-US&page=1`,
        headers: {
          Accept: 'application/json',
          Authorization: 'Bearer eyJhbGciOiJIUzI1NiJ9...',
        },
      });
      setSearchedMovieList(response.data.results);
      setTotalPages(response.data.total_pages);
    } catch (error) {
      console.error('Search failed:', error); 
      alert('Failed to search for movies.');   
    }
  }, [query]);
  

  const handleSelectMovie = (movie) => {
    setSelectedMovie(movie);
  };
  

  const handleSave = async () => {
    const accessToken = localStorage.getItem('accessToken');
    if (selectedMovie === undefined) {
      alert('Please search and select a movie.');
      return;
    }
    const Form = () => {
      const navigate = useNavigate();  
      const handleSave = async () => {
        if (selectedMovie === undefined) {
          alert('Please select a movie.');
          return;
        }
        try {
          await axios.post('/movies', {
            tmdbId: selectedMovie.id,
          }, {
            headers: {
              Authorization: `Bearer ${localStorage.getItem('accessToken')}`,
            }
          });
          alert('Movie saved successfully.');
          navigate('/main/movies'); 
        } catch (error) {
          console.error('Save failed:', error);
          alert('Failed to save movie.');
        }
      };
    };
    
    const data = {
      tmdbId: selectedMovie.id,
      title: selectedMovie.title,
      overview: selectedMovie.overview,
      popularity: selectedMovie.popularity,
      releaseDate: selectedMovie.release_date,
      voteAverage: selectedMovie.vote_average,
      backdropPath: `https://image.tmdb.org/t/p/original/${selectedMovie.backdrop_path}`,
      posterPath: `https://image.tmdb.org/t/p/original/${selectedMovie.poster_path}`,
      isFeatured: 0,
    };
  
    try {
      const saveResponse = await axios({
        method: 'post',
        url: '/movies',
        data: data,
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      });
      console.log(saveResponse);
      alert('Movie saved successfully.');
    } catch (error) {
      console.error('Save failed:', error); 
      alert('Failed to save the movie.');   
    }
  };
  
// handleSave function here

const handleDelete = async (movieId) => {
  const accessToken = localStorage.getItem('accessToken');
  try {
    await axios.delete(`/movies/${movieId}`, {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    });
    alert('Movie deleted successfully.');
  } catch (error) {
    console.error('Delete failed:', error);
    alert('Failed to delete the movie.');
  }
};

  //create a form change/validation
  //create a new handler for update
  useEffect(() => {
    if (movieId) {
      axios.get(`/movies/${movieId}`).then((response) => {
        setMovie(response.data);
        const tempData = {
          id: response.data.tmdbId,
          original_title: response.data.title,
          overview: response.data.overview,
          popularity: response.data.popularity,
          poster_path: response.data.posterPath,
          release_date: response.data.releaseDate,
          vote_average: response.data.voteAverage,
        };
        setSelectedMovie(tempData);
        console.log(response.data);
      });
    } 
  }, []);

  return (
    <>
      <h1>{movieId !== undefined ? 'Edit ' : 'Create '} Movie</h1>

      {movieId === undefined && (
  <>
    <div className='search-container'>
      Search Movie:
      <input type='text'
        onChange={(event) => setQuery(event.target.value)}
      />
      <button type='button' onClick={handleSearch}>
        Search
      </button>
      <div className='searched-movie'>
        {searchedMovieList.map((movie) => (
          <p key={movie.id} onClick={() => handleSelectMovie(movie)}>
            {movie.original_title}
          </p>
        ))}
      </div>
    </div>

    <div className='pagination'>
      <button
      disabled={currentPage === 1}
      onClick={() => setCurrentPage(currentPage - 1)}
    >
    Previous
    </button>
  <span> Page {currentPage} of {Math.ceil(searchedMovieList.length / moviesPerPage)} </span>
  <button
    disabled={currentPage === Math.ceil(searchedMovieList.length / moviesPerPage)}
    onClick={() => setCurrentPage(currentPage + 1)}
    >
    Next
    </button>
  </div>


    <hr />
  </>
)}


      <div className='container'>
        <form>
          {selectedMovie ? (
            <img
              className='poster-image'
              src={`https://image.tmdb.org/t/p/original/${selectedMovie.poster_path}`}
            />
          ) : (
            ''
          )}
          <div className='field'>
            Title:
            <input
              type='text'
              value={selectedMovie ? selectedMovie.original_title : ''}
            />
          </div>
          <div className='field'>
            Overview:
            <textarea
              rows={10}
              value={selectedMovie ? selectedMovie.overview : ''}
            />
          </div>

          <div className='field'>
            Popularity:
            <input
              type='text'
              value={selectedMovie ? selectedMovie.popularity : ''}
            />
          </div>

          <div className='field'>
            Release Date:
            <input
              type='text'
              value={selectedMovie ? selectedMovie.release_date : ''}
            />
          </div>

          <div className='field'>
            Vote Average:
            <input
              type='text'
              value={selectedMovie ? selectedMovie.vote_average : ''}
            />
          </div>

          <button type='button' onClick={handleSave}>
            Save
          </button>
        </form>
      </div>
    </>
  );
};

export default Form;
