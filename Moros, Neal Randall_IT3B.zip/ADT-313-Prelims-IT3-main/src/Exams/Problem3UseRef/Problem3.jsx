import { useRef } from 'react';
  
function Problem3() {
  const inputRef = useRef(null);

  function handleClick() {
    inputRef.current.focus();
  }
  return (
    <>
      <div style={{ display: 'block' }}>
        Input 1: <input ref={inputRef}/>
      </div>
      <div style={{ display: 'block' }}>
        Input 2: <input ref={inputRef}/>
      </div>
      <div style={{ display: 'block' }}>
        Input 3: <input ref={inputRef}/>
      </div>
      <div style={{ display: 'block' }}>
        Input 4: <input ref={inputRef}/>
      </div>
      <div style={{ display: 'block' }}>
        Input 5: <input ref={inputRef}/>
      </div>
      <div style={{ display: 'block' }}>
        Input 6: <input ref={inputRef}/>
      </div>
      <div style={{ display: 'block' }}>
        Input 7: <input ref={inputRef}/>
      </div>
      <div style={{ display: 'block' }}>
        Input 8: <input ref={inputRef}/>
      </div>
      <div style={{ display: 'block' }}>
        Input 9: <input ref={inputRef}/>
      </div>
      <div style={{ display: 'block' }}>
        Input 10: <input ref={inputRef}/>
      </div>
       
      <button onClick={handleClick}>
        I am a button
      </button>
      
    </>
  );
}

export default Problem3;
