import { useState } from 'react';

function Problem4() {
  
  const [form, setForm] = useState({
  });
  
  return (
    <>
      <div style={{ display: 'block' }}>
        Name: <input type='text' />
        <input value={form.name}onChange={e => {setForm({form,name: e.target.value});}}/>
      </div>
      
      <div style={{ display: 'block' }}>
        <p>Yearlevel:</p>
        <input
          type='radio'
          id='firstYear'
          name='yearlevel'
          value='Fist Year'
        />
          <label for='firstYear'>Fist Year</label>
            <input value={form.yearLevel}onChange={e => {setForm({form,yearLevel: e.target.value});}}/>
        <br></br>
        <input
          type='radio'
          id='secondYear'
          name='yearlevel'
          value='Second Year'
        />
          <label for='secondYear'>Second Year</label>
            <input value={form.yearLevel}onChange={e => {setForm({form,yearLevel: e.target.value});}}/>
        <br></br>
        <input
          type='radio'
          id='thirdYear'
          name='yearlevel'
          value='Third Year'
        />
          <label for='thirdYear'>Third Year</label>
            <input value={form.yearLevel}onChange={e => {setForm({form,yearLevel: e.target.value});}}/>
        <br></br>
        <input
          type='radio'
          id='fourthYear'
          name='yearlevel'
          value='Fourth Year'
        />
          <label for='fourthYear'>Fourth Year</label>
            <input value={form.yearLevel}onChange={e => {setForm({form,yearLevel: e.target.value});}}/>
        <br></br>
        <input
          type='radio'
          id='fifthYear'
          name='yearlevel'
          value='Fourth Year'
        />
          <label for='fifthYear'>Fifth Year</label>
            <input value={form.yearLevel}onChange={e => {setForm({form,yearLevel: e.target.value});}}/>
        <br></br>
        <input type='radio' id='irregular' name='yearlevel' value='Irregular' />
          <label for='irregular'>Irregular</label>
            <input value={form.yearLevel}onChange={e => {setForm({form,yearLevel: e.target.value});}}/>
        <br></br>
      </div>

      <div style={{ display: 'block' }}>
        Course:
        <select>
          <option value='BSCS'>BSCS</option>
          <option value='BSIT'>BSIT</option>
          <option value='BSCpE'>BSCpE</option>
          <option value='ACT'>ACT</option>
        </select>
        <input value={form.course}onChange={e => {setForm({form,course: e.target.value});}}/>
      </div>
      
      <p>
        {form.name}{' '}
        {form.yearLevel}{' '}
        ({form.course})
      </p>
    </>
  );
}

export default Problem4