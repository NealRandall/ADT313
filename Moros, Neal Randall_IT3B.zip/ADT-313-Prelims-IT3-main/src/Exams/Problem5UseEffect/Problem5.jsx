import { useEffect, useRef, useState } from 'react';
import Loading from './Problem5Components/Loading';

function Problem5() {
  const idleRef = useRef(null);
  const [isLoading, setIsLoading] = useState(true);
useEffect(()=> {
  setIsLoading(false)
  console.log("setLoading to false.")  
}, [])
useEffect(() => {
  if(isLoading == false)
  {
      console.log("Loading verified to be false");
  }
},[isLoading])

return (
  <>
    {isLoading ? (
      <Loading />
    ) : (
      <>
        <div style={{ display: 'block' }}>
          Input: <input type='text' />
          <p>User is idle...</p>
        </div>
      </>
    )}
  </>
);
}

export default Problem5